## AWS C Event Stream

C99 implementation of the vnd.amazon.event-stream content-type.

## License

This library is licensed under the Apache 2.0 License. 
