﻿/**
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0.
 */

#pragma once
#include <cstddef>
#include <aws/AWSMigrationHub/MigrationHub_EXPORTS.h>

namespace Aws
{
namespace MigrationHub
{
class MigrationHubEndpointRules
{
public:
    static const size_t RulesBlobStrLen;
    static const size_t RulesBlobSize;

    static const char* GetRulesBlob();
};
} // namespace MigrationHub
} // namespace Aws
