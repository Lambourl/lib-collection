# Verify legacy CMake and Bazel targets remain usable

This directory contains backwards compatibility tests for our CMake and Bazel
deprecated targets. These targets should remain usable until they are retired
(as opposed to simply "no longer recommended"), usually a year after they are
deprecated.
